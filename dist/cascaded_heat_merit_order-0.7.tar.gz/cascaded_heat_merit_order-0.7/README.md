## Cascaded Heat Merit Order

Tool for calculating a factory-wide merit order of heat-flows of industrial energy systems.